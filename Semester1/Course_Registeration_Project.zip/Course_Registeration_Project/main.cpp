#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

const int MAX_COURSES = 10;
const int MAX_STUDENTS = 100;
const int MAX_STRING_LENGTH = 100;
char** courseCodes;
char** courseTitles;
int* seatsAvailable;
char*** studentRegistrations; 
int currentStudentCount = 0;
int currentCourseCount = 0;
char* loggedInUsername = nullptr;
bool checkingEqual(const char* string1, const char* string2) {
    while (*string1 && *string2) {
        if (*string1 != *string2) return false;
        ++string1;
        ++string2;
    }
    return *string1 == *string2;
}

char* coptingText(const char* te) {
    if (!te) return nullptr;
    int length = 0;
    while (te[length] != '\0') length++;
    
    char* dest = new char[length + 1];
    for (int i = 0; i <= length; i++) {
        dest[i] = te[i];
    }
    return dest;
}

void initializeData() {
    courseCodes = new char*[MAX_COURSES];
    courseTitles = new char*[MAX_COURSES];
    seatsAvailable = new int[MAX_COURSES];
    
    for (int i = 0; i < MAX_COURSES; i++) {
        courseCodes[i] = nullptr;
        courseTitles[i] = nullptr;
        seatsAvailable[i] = 0;
    }
    studentRegistrations = new char**[MAX_STUDENTS];
    for (int i = 0; i < MAX_STUDENTS; i++) {
        studentRegistrations[i] = new char*[MAX_COURSES];
        for (int j = 0; j < MAX_COURSES; j++) {
            studentRegistrations[i][j] = nullptr;
        }
    }
}

void loadCourses() {
    ifstream infile("courses.txt");
    
    if (!infile.is_open()) {
        ofstream outfile("courses.txt");
        const char* defaultCourses[10][3] = {
            {"CS101", "Intro to CS", "25"},
            {"MAT201", "Calculus I", "40"},
            {"PHYS102", "Physics", "35"},
            {"CHEM103", "Chemistry", "25"},
            {"ENG104", "English", "50"},
            {"HIST112", "World History", "45"},
            {"DS106", "Introductory DM", "50"},
            {"ART107", "Art Appreciation", "60"},
            {"ECON111", "Principles of Economics", "40"},
            {"PSY110", "Psychology", "54"}
        };
        for (int i = 0; i < 10; i++) {
            outfile << defaultCourses[i][0] << "," 
                   << defaultCourses[i][1] << "," 
                   << defaultCourses[i][2] << endl;
        }
        outfile.close();
        
        infile.open("courses.txt");
    }
    
    char line[MAX_STRING_LENGTH * 3];
    int index = 0;
    
    while (infile.getline(line, sizeof(line))) {
        char* code = strtok(line, ",");
        char* title = strtok(nullptr, ",");
        char* seatsStr = strtok(nullptr, ",");
        
        if (code && title && seatsStr) {
            courseCodes[index] = coptingText(code);
            courseTitles[index] = coptingText(title);
            seatsAvailable[index] = atoi(seatsStr);
            index++;
        }
    }
    currentCourseCount = index;
    infile.close();
}

void loadStudents() {
    ifstream file("students.txt");
    if (!file.is_open()) return;
    
    char line[MAX_STRING_LENGTH * 4];
    int index = 0;
    
    while (file.getline(line, sizeof(line))) {
        char* id = strtok(line, ",");
        char* name = strtok(nullptr, ",");
        char* username = strtok(nullptr, ",");
        char* password = strtok(nullptr, ",");
        index++;
    }
    currentStudentCount = index;
    file.close();
}

void loadRegistrations() {
    ifstream file("registrations.txt");
    if (!file.is_open()) return;
    
    char line[MAX_STRING_LENGTH * (MAX_COURSES + 1)];
    
    while (file.getline(line, sizeof(line))) {
        char* studentId = strtok(line, ":");
        char* course = strtok(nullptr, ",");
        
        int studentIndex = -1;
        
        int courseIndex = 0;
        while (course != nullptr && courseIndex < MAX_COURSES) {
            for (int i = 0; i < currentCourseCount; i++) {
                if (checkingEqual(courseCodes[i], course)) {
                    if (studentIndex != -1) {
                        studentRegistrations[studentIndex][courseIndex] = coptingText(course);
                    }
                    break;
                }
            }
            course = strtok(nullptr, ",");
            courseIndex++;
        }
    }
    file.close();
}

void saveCourses() {
    ofstream file("courses.txt");
    for (int i = 0; i < currentCourseCount; i++) {
        file << courseCodes[i] << "," << courseTitles[i] << "," << seatsAvailable[i] << endl;
    }
    file.close();
}

void saveRegistrations() {
    ofstream file("registrations.txt");
    file.close();
}

void viewAvailableCourses() {
    cout << "\nAvailable Courses:\n";
    cout << "Code\tTitle\t\t\tAvailable Seats\n";
    cout << "--------------------------------------------\n";
    
    for (int i = 0; i < currentCourseCount; i++) {
        cout << courseCodes[i] << "\t" << courseTitles[i] << "\t\t" << seatsAvailable[i] << endl;
    }
}

void registerForCourse() {
    if (!loggedInUsername) return;
    
    viewAvailableCourses();
    cout << "\nEnter course code to register: ";
    char courseCode[MAX_STRING_LENGTH];
    cin.getline(courseCode, MAX_STRING_LENGTH);
    
    int courseIndex = -1;
    for (int i = 0; i < currentCourseCount; i++) {
        if (checkingEqual(courseCodes[i], courseCode)) {
            courseIndex = i;
            break;
        }
    }
    
    if (courseIndex == -1) {
        cout << "Course not found!\n";
        return;
    }
    
    if (seatsAvailable[courseIndex] <= 0) {
        cout << "No seats available for this course!\n";
        return;
    }
    
    int studentIndex = 0; 
    
    for (int i = 0; i < MAX_COURSES; i++) {
        if (studentRegistrations[studentIndex][i] && 
            checkingEqual(studentRegistrations[studentIndex][i], courseCode)) {
            cout << "You are already registered for this course!\n";
            return;
        }
    }
    for (int i = 0; i < MAX_COURSES; i++) {
        if (!studentRegistrations[studentIndex][i]) {
            studentRegistrations[studentIndex][i] = coptingText(courseCode);
            seatsAvailable[courseIndex]--;
            cout << "Successfully registered for " << courseCode << endl;
            saveCourses();
            saveRegistrations();
            return;
        }
    }
    
    cout << "You have reached the maximum number of courses!\n";
}

void dropCourse() {
    if (!loggedInUsername) return;
    
    int studentIndex = 0; 
    
    cout << "\nYour Registered Courses:\n";
    bool hasCourses = false;
    for (int i = 0; i < MAX_COURSES; i++) {
        if (studentRegistrations[studentIndex][i]) {
            cout << studentRegistrations[studentIndex][i] << endl;
            hasCourses = true;
        }
    }
    
    if (!hasCourses) {
        cout << "You are not registered for any courses!\n";
        return;
    }
    
    cout << "\nEnter course code to drop: ";
    char courseCode[MAX_STRING_LENGTH];
    cin.getline(courseCode, MAX_STRING_LENGTH);
    
    for (int i = 0; i < MAX_COURSES; i++) {
        if (studentRegistrations[studentIndex][i] && 
            checkingEqual(studentRegistrations[studentIndex][i], courseCode)) {
            for (int j = 0; j < currentCourseCount; j++) {
                if (checkingEqual(courseCodes[j], courseCode)) {
                    seatsAvailable[j]++;
                    break;
                }
            }
            
            delete[] studentRegistrations[studentIndex][i];
            studentRegistrations[studentIndex][i] = nullptr;
            
            cout << "Successfully dropped " << courseCode << endl;
            saveCourses();
            saveRegistrations();
            return;
        }
    }
    
    cout << "You are not registered for this course!\n";
}

void viewMyCourses() {
    if (!loggedInUsername) return;
    int studentIndex = 0; 
    cout << "\nYour Registered Courses:\n";
    bool hasCourses = false;
    for (int i = 0; i < MAX_COURSES; i++) {
        if (studentRegistrations[studentIndex][i]) {
            for (int j = 0; j < currentCourseCount; j++) {
                if (checkingEqual(courseCodes[j], studentRegistrations[studentIndex][i])) {
                    cout << courseCodes[j] << " - " << courseTitles[j] << endl;
                    hasCourses = true;
                    break;
                }
            }
        }
    }
    
    if (!hasCourses) {
        cout << "You are not registered for any courses!\n";
    }
}

void changePassword() {
    if (!loggedInUsername) return;

    cout << "\nChange Password\n";
    char currentPassword[MAX_STRING_LENGTH];
    char newPassword[MAX_STRING_LENGTH];
    char confirmPassword[MAX_STRING_LENGTH];

    cout << "Enter current password: ";
    cin.getline(currentPassword, MAX_STRING_LENGTH);

    ifstream infile("students.txt");
    ofstream outfile("students_temp.txt");
    bool passwordChanged = false;
    char line[MAX_STRING_LENGTH * 4];

    while (infile.getline(line, sizeof(line))) {
        char* id = strtok(line, ",");
        char* name = strtok(nullptr, ",");
        char* username = strtok(nullptr, ",");
        char* password = strtok(nullptr, ",");
        int plen = 0;
        while (password && password[plen] != '\0') plen++;
        if (plen > 0 && (password[plen-1] == '\n' || password[plen-1] == '\r'))
            password[plen-1] = '\0';

        if (username && checkingEqual(username, loggedInUsername)) {
            if (!checkingEqual(currentPassword, password)) {
                cout << "Current password is incorrect!\n";
                outfile << id << "," << name << "," << username << "," << password << endl;
                continue;
            }

            cout << "Enter new password: ";
            cin.getline(newPassword, MAX_STRING_LENGTH);

            cout << "Confirm new password: ";
            cin.getline(confirmPassword, MAX_STRING_LENGTH);

            if (!checkingEqual(newPassword, confirmPassword)) {
                cout << "Passwords do not match!\n";
                outfile << id << "," << name << "," << username << "," << password << endl;
                continue;
            }
            outfile << id << "," << name << "," << username << "," << newPassword << endl;
            passwordChanged = true;
            cout << "Password changed successfully!\n";
        } else {
            outfile << id << "," << name << "," << username << "," << password << endl;
        }
    }
    infile.close();
    outfile.close();
    remove("students.txt");
    rename("students_temp.txt", "students.txt");

    if (!passwordChanged) {
        cout << "Password was not changed.\n";
    }
}

void signOut() {
    if (loggedInUsername) {
        delete[] loggedInUsername;
        loggedInUsername = nullptr;
    }
    cout << "Signed out successfully!\n";
}

void afterSignInMenu() {
    int choice;
    do {
        cout << "\n--- Student Course Registration System ---\n";
        cout << "1. View Available Courses\n";
        cout << "2. Register for a Course\n";
        cout << "3. Drop a Course\n";
        cout << "4. View My Courses\n";
        cout << "5. Change Password\n";
        cout << "6. Sign Out\n";
        cout << "Enter your choice (1-6): ";
        cin >> choice;
        cin.ignore(); 
        while(choice < 1 || choice > 6 || cin.fail()) {
            cin.clear(); 
            cin.ignore(1000, '\n');
            cout << "Invalid choice. enter a number between 1-6: ";
            cin >> choice;
            cin.ignore();
        }
        
        switch (choice) {
            case 1: viewAvailableCourses(); break;
            case 2: registerForCourse(); break;
            case 3: dropCourse(); break;
            case 4: viewMyCourses(); break;
            case 5: changePassword(); break;
            case 6: signOut(); break;
            default: cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 6 && loggedInUsername);
}

void signIn() {
    char username[MAX_STRING_LENGTH];
    char password[MAX_STRING_LENGTH];
    char fileId[MAX_STRING_LENGTH], fileName[MAX_STRING_LENGTH], fileUsername[MAX_STRING_LENGTH], filePassword[MAX_STRING_LENGTH];
    bool found = false;

    cout << "\nSign In\n";
    cout << "Username: ";
    cin.getline(username, MAX_STRING_LENGTH);

    cout << "Password: ";
    cin.getline(password, MAX_STRING_LENGTH);

    ifstream file("students.txt");
    while (file.getline(fileId, MAX_STRING_LENGTH, ',') &&
           file.getline(fileName, MAX_STRING_LENGTH, ',') &&
           file.getline(fileUsername, MAX_STRING_LENGTH, ',') &&
           file.getline(filePassword, MAX_STRING_LENGTH))
    {
        int len = 0;
        while (filePassword[len] != '\0') len++;
        if (len > 0 && (filePassword[len-1] == '\n' || filePassword[len-1] == '\r'))
            filePassword[len-1] = '\0';

        if (checkingEqual(username, fileUsername) && checkingEqual(password, filePassword)) {
            found = true;
            break;
        }
    }
    file.close();

    if (found) {
        loggedInUsername = coptingText(username);
        cout << "Login successful!\n";
        afterSignInMenu();
    } else {
        cout << "Invalid username or password!\n";
    }
}

void signUp() {
    char id[MAX_STRING_LENGTH];
    char name[MAX_STRING_LENGTH];
    char username[MAX_STRING_LENGTH];
    char password[MAX_STRING_LENGTH];
    char confirmPassword[MAX_STRING_LENGTH];
    
    cout << "\nSign Up\n";
    cout << "Student ID: ";
    cin.getline(id, MAX_STRING_LENGTH);
    
    cout << "Full Name: ";
    cin.getline(name, MAX_STRING_LENGTH);
    
    cout << "Username: ";
    cin.getline(username, MAX_STRING_LENGTH);
    
    cout << "Password: ";
    cin.getline(password, MAX_STRING_LENGTH);
    
    cout << "Confirm Password: ";
    cin.getline(confirmPassword, MAX_STRING_LENGTH);
    
    if (!checkingEqual(password, confirmPassword)) {
        cout << "Passwords do not match!\n";
        return;
    }
    
    ofstream file("students.txt", ios::app);
    file << id << "," << name << "," << username << "," << password << endl;
    file.close();
    
    cout << "Registration successful! You can now sign in.\n";
}

void mainMenu() {
    int choice;
    do {
        cout << "\n--- Welcome to Student Course Registration System ---\n";
        cout << "1. Sign Up\n";
        cout << "2. Sign In\n";
        cout << "3. Exit\n";
        cout << "Enter your choice (1-3): ";
        cin >> choice;
        cin.ignore(); while(choice < 1 || choice > 6 || cin.fail()) {
            cin.clear(); 
            cin.ignore(1000, '\n');
            cout << "Invalid choice. enter a number between 1 and 3: ";
            cin >> choice;
            cin.ignore();
        }


        
        switch (choice) {
            case 1: signUp(); break;
            case 2: signIn(); break;
            case 3: cout << "Exiting system. Goodbye!\n"; break;
            default: cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 3);
}

void cleanup() {
    for (int i = 0; i < MAX_COURSES; i++) {
        if (courseCodes[i]) delete[] courseCodes[i];
        if (courseTitles[i]) delete[] courseTitles[i];
    }
    delete[] courseCodes;
    delete[] courseTitles;
    delete[] seatsAvailable;
    
    for (int i = 0; i < MAX_STUDENTS; i++) {
        for (int j = 0; j < MAX_COURSES; j++) {
            if (studentRegistrations[i][j]) delete[] studentRegistrations[i][j];
        }
        delete[] studentRegistrations[i];
    }
    delete[] studentRegistrations;
    
    if (loggedInUsername) delete[] loggedInUsername;
}

int main() {
    initializeData();
    loadCourses();
    loadStudents();
    loadRegistrations();
    
    mainMenu();
    
    cleanup();
    return 0;
}